#include <stdio.h>
#include <math.h>  

#define N 4

int main() {
    float mat[N][N+1];  
    int i, j, k, maxFila;
    float factor, temp;

    printf("==========================================\n");
    printf("  ESTE ES SOLO UNA PRUEBA DEL LABORATORIO \n");
    printf("  FUNDACION UNIVERSITARIA INTER LA RIOJA \n");
    printf("==========================================\n\n");
    fflush(stdout);

    printf("Ingrese los coeficientes del sistema (4x4) y el vector resultado:\n");
    fflush(stdout);
    for (i = 0; i < N; i++) {
        for (j = 0; j <= N; j++) {
            scanf("%f", &mat[i][j]);
        }
    }

    for (i = 0; i < N; i++) {
        maxFila = i;
        for (k = i + 1; k < N; k++) {
            if (fabs(mat[k][i]) > fabs(mat[maxFila][i])) {
                maxFila = k;
            }
        }
        for (j = 0; j <= N; j++) {
            temp = mat[i][j];
            mat[i][j] = mat[maxFila][j];
            mat[maxFila][j] = temp;
        }

        temp = mat[i][i];
        for (j = i; j <= N; j++) {
            mat[i][j] /= temp;
        }

        for (k = i + 1; k < N; k++) {
            factor = mat[k][i];
            for (j = i; j <= N; j++) {
                mat[k][j] -= factor * mat[i][j];
            }
        }
    }

    for (i = N - 1; i >= 0; i--) {
        for (j = i - 1; j >= 0; j--) {
            factor = mat[j][i];
            mat[j][i] = 0;
            mat[j][N] -= factor * mat[i][N];
        }
    }
    printf("\nSoluciones:\n");
    fflush(stdout);
    for (i = 0; i < N; i++) {
        printf("X%d = %.6f\n", i + 1, mat[i][N]);
    }
    printf("\n==========================================\n");
    printf("  ESTE TRABAJO ES DE JOSETH FELIPE SANCHEZ BUSTOS \n");
    printf("==========================================\n");
    fflush(stdout);

    return 0;
}
